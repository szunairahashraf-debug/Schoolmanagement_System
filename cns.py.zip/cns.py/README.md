# School Management System

## Description
Yeh project Python mein bana hai jo students ka data manage karta hai.

## Features
- Add Student
- Remove Student
- View Students

## Technologies Used
- Python

## How to Run
1. Python install karo
2. File run karo

## Author
syeda zunairah
Maryam Rajput
Mehwish Nadeem
