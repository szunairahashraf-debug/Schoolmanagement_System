# CODENEST SCHOOL:
# https://codenestschool.com/
students = []
teachers = []
fees = []
results = []
attendance = []

# ================= STUDENT =================
def add_student():
    name = input("Name: ")
    s_class = input("Class: ")
    age = input("Age: ")
    roll = input("Roll No: ")

    students.append({
        "name": name,
        "class": s_class,
        "age": age,
        "roll": roll
    })
    print(" Student added!")

def remove_student():
    roll = input("Enter Roll No: ")
    for s in students:
        if s["roll"] == roll:
            students.remove(s)
            print("Removed!")
            return
    print("Not found")

def view_students():
    for s in students:
        print(s)

def search_student():
    name = input("Enter name: ")
    for s in students:
        if s["name"].lower() == name.lower():
            print(s)
            return
    print(" Not found")

# ================= TEACHER =================
def add_teacher():
    name = input("Name: ")
    subject = input("Subject: ")
    salary = input("Salary: ")
    duty = input("Duty: ")

    teachers.append({
        "name": name,
        "subject": subject,
        "salary": salary,
        "duty": duty
    })
    print("Teacher added!")

def view_teachers():
    for t in teachers:
        print(t)

# ================= ATTENDANCE =================
def mark_attendance():
    name = input("Name: ")
    status = input("Present/Absent: ")

    attendance.append({
        "name": name,
        "status": status
    })
    print("Attendance marked!")

def view_attendance():
    for a in attendance:
        print(a)

# ================= FEE =================
def add_fee():
    name = input("Student name: ")
    status = input("Paid/Unpaid: ")

    fees.append({
        "name": name,
        "status": status
    })
    print("Fee record added!")

def view_fees():
    for f in fees:
        print(f)

# ================= RESULT =================
def add_result():
    name = input("Student name: ")
    marks = int(input("Marks: "))

    if marks >= 80:
        grade = "A"
    elif marks >= 60:
        grade = "B"
    elif marks >= 40:
        grade = "C"
    else:
        grade = "Fail"

    results.append({
        "name": name,
        "marks": marks,
        "grade": grade
    })

    print("Result added!")

def view_results():
    for r in results:
        print(r)

# ================= MENU =================
while True:
    print("\n===== SCHOOL MANAGEMENT SYSTEM =====")
    print("1. Add Student")
    print("2. Remove Student")
    print("3. View Students")
    print("4. Search Student")

    print("5. Add Teacher")
    print("6. View Teachers")

    print("7. Mark Attendance")
    print("8. View Attendance")

    print("9. Add Fee Record")
    print("10. View Fees")

    print("11. Add Result")
    print("12. View Results")

    print("13. Exit")

    choice = input("Enter choice: ")

    if choice == "1":
        add_student()
    elif choice == "2":
        remove_student()
    elif choice == "3":
        view_students()
    elif choice == "4":
        search_student()
    elif choice == "5":
        add_teacher()
    elif choice == "6":
        view_teachers()
    elif choice == "7":
        mark_attendance()
    elif choice == "8":
        view_attendance()
    elif choice == "9":
        add_fee()
    elif choice == "10":
        view_fees()
    elif choice == "11":
        add_result()
    elif choice == "12":
        view_results()
    elif choice == "13":
        print("System Closed")
        break
    else:
        print("Invalid choice")